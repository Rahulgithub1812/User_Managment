﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Controllers;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UnitTesting
{
    public class UserManagementControllerTests
    {
        private readonly Mock<IUserService> _userServiceMock = new Mock<IUserService>();
        private readonly UserManagementController _controller;

        public UserManagementControllerTests()
        {
            _controller = new UserManagementController(_userServiceMock.Object);
        }

        [Fact]
        public void GetAllUsers_ReturnsAllUsers()
        {
            // Arrange
            var users = new List<User> { new User { Id = 1, Username = "User1" } };
            _userServiceMock.Setup(x => x.GetAllUsers()).Returns(users);

            // Act
            var result = _controller.GetAllUsers() as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(users, result.Value);
            Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        }

        // Similar tests for UpdateRole and DeleteUser actions
    }

}
