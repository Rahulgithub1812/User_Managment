﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Controllers;
using UserManagement.Services.Interface;

namespace UnitTesting
{
    public class IngestionControllerTests
    {
        private readonly Mock<IIngestionService> _ingestionServiceMock = new Mock<IIngestionService>();
        private readonly IngestionController _controller;

        public IngestionControllerTests()
        {
            _controller = new IngestionController(_ingestionServiceMock.Object);
        }

        [Fact]
        public async Task Trigger_ReturnsOk()
        {
            // Arrange
            _ingestionServiceMock.Setup(x => x.TriggerIngestionAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.Trigger() as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Ingestion triggered", result.Value);
            Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        }

        // Similar tests for Status and Cancel actions
    }

}
