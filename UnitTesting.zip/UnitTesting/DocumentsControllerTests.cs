﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using UserManagement.Controllers;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UnitTesting
{
    public class DocumentsControllerTests
    {
        private readonly Mock<IDocumentService> _documentServiceMock = new Mock<IDocumentService>();
        private readonly DocumentsController _controller;

        public DocumentsControllerTests()
        {
            _controller = new DocumentsController(_documentServiceMock.Object);
        }

        [Fact]
        public void GetAll_ReturnsAllDocuments()
        {
            // Arrange
            var documents = new List<Document> { new Document { Id = 1, Name = "Doc1", Content = "Content1" } };
            _documentServiceMock.Setup(x => x.GetAllDocuments()).Returns(documents);

            // Act
            var result = _controller.GetAll() as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(documents, result.Value);
            Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        }

        // Similar tests for GetById, Upload, Update, and Delete actions
    }

}
