﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagement.Controllers;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UnitTesting
{
    public class AuthControllerTests
    {
        private readonly Mock<IAuthService> _authServiceMock = new Mock<IAuthService>();
        private readonly AuthController _controller;

        public AuthControllerTests()
        {
            _controller = new AuthController(_authServiceMock.Object);
        }

        [Fact]
        public void Login_ValidCredentials_ReturnsToken()
        {
            // Arrange
            var loginDto = new User { Username = "Rahul", Password = "123456" };
            var expectedToken = "mocked_token";
            _authServiceMock.Setup(x => x.Login(loginDto.Username, loginDto.Password)).Returns(expectedToken);

            // Act
            var result = _controller.Login(loginDto) as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedToken, result.Value);
            Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        }

        [Fact]
        public void Login_InvalidCredentials_ReturnsUnauthorized()
        {
            // Arrange
            var loginDto = new User { Username = "invaliduser", Password = "invalidpassword" };
            _authServiceMock.Setup(x => x.Login(loginDto.Username, loginDto.Password)).Returns((string)null);

            // Act
            var result = _controller.Login(loginDto) as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Invalid credentials", result.Value);
            Assert.Equal(StatusCodes.Status401Unauthorized, result.StatusCode);
        }

        [Fact]
        public void Register_Success_ReturnsOk()
        {
            // Arrange
            var registerDto = new User { Username = "newuser", Password = "newpassword", Role = "User" };
            _authServiceMock.Setup(x => x.Register(registerDto.Username, registerDto.Password, registerDto.Role)).Returns(true);

            // Act
            var result = _controller.Register(registerDto) as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Registered successfully", result.Value);
            Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        }

        [Fact]
        public void Register_UserExists_ReturnsBadRequest()
        {
            // Arrange
            var registerDto = new User { Username = "existinguser", Password = "password", Role = "User" };
            _authServiceMock.Setup(x => x.Register(registerDto.Username, registerDto.Password, registerDto.Role)).Returns(false);

            // Act
            var result = _controller.Register(registerDto) as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("User already exists", result.Value);
            Assert.Equal(StatusCodes.Status400BadRequest, result.StatusCode);
        }
    }

}
