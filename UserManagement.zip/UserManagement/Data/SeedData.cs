﻿using Microsoft.EntityFrameworkCore;
using UserManagement.Models;

namespace UserManagement.Data
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using var context = new ProDBContext(
                serviceProvider.GetRequiredService<DbContextOptions<ProDBContext>>()
            );

            if (context.Users.Any()) return;

            context.Users.Add(new User
            {
                Username = "admin",
                Password = "admin123", // Replace with hashed password in production
                Role = "Admin"
            });

            context.SaveChanges();
        }
    }
}
