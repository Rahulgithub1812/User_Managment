﻿using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata;
using UserManagement.Models;
using Document = UserManagement.Models.Document;

namespace UserManagement.Data
{
    public class ProDBContext : DbContext
    {
        public ProDBContext(DbContextOptions<ProDBContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Document> Documents { get; set; }
    }
}
