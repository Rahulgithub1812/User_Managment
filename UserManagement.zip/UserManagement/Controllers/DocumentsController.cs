﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UserManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class DocumentsController : ControllerBase
    {
        private readonly IDocumentService _documentService;

        public DocumentsController(IDocumentService documentService)
        {
            _documentService = documentService;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll() => Ok(_documentService.GetAllDocuments());

        [HttpGet("GetById/{id}")]
        public IActionResult GetById(int id)
        {
            var doc = _documentService.GetDocumentById(id);
            return doc == null ? NotFound() : Ok(doc);
        }

        [HttpPost("Upload")]
        public IActionResult Upload(Document dto)
        {
            var doc = new Document { Name = dto.Name, Content = dto.Content };
            _documentService.UploadDocument(doc);
            return Ok("Uploaded");
        }

        [HttpPut("Update/{id}")]
        public IActionResult Update(int id, Document dto)
        {
            var doc = _documentService.GetDocumentById(id);
            if (doc == null) return NotFound();
            doc.Name = dto.Name;
            doc.Content = dto.Content;
            _documentService.UpdateDocument(doc);
            return Ok("Updated");
        }

        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            _documentService.DeleteDocument(id);
            return Ok("Deleted");
        }
    }
}
