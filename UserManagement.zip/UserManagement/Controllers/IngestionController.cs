﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using UserManagement.Services.Interface;

namespace UserManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,Editor")]
    public class IngestionController : ControllerBase
    {
        private readonly IIngestionService _ingestionService;

        public IngestionController(IIngestionService ingestionService)
        {
            _ingestionService = ingestionService;
        }

        [HttpPost("trigger")]
        public async Task<IActionResult> Trigger()
        {
            await _ingestionService.TriggerIngestionAsync();
            return Ok("Ingestion triggered");
        }

        [HttpGet("status")]
        public async Task<IActionResult> Status()
        {
            var status = await _ingestionService.GetIngestionStatusAsync();
            return Ok(status);
        }

        [HttpPost("cancel")]
        public async Task<IActionResult> Cancel()
        {
            var result = await _ingestionService.CancelIngestionAsync();
            return result ? Ok("Canceled") : BadRequest("Cancel failed");
        }
    }
}
