﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UserManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public IActionResult Login(User loginDto)
        {
            var token = _authService.Login(loginDto.Username, loginDto.Password);
            if (token == null) return Unauthorized("Invalid credentials");
            return Ok(new { Token = token });
        }

        [HttpPost("register")]
        public IActionResult Register(User registerDto)
        {
            var success = _authService.Register(registerDto.Username, registerDto.Password, registerDto.Role);
            if (!success) return BadRequest("User already exists");
            return Ok("Registered successfully");
        }
    }
}
