﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using UserManagement.Services.Interface;

namespace UserManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class UserManagementController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserManagementController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("GetAllUsers")]
        public IActionResult GetAllUsers() => Ok(_userService.GetAllUsers());

        [HttpPut("UpdateRole/{id}")]
        public IActionResult UpdateRole(int id, [FromQuery] string newRole)
        {
            if (_userService.UpdateUserRole(id, newRole))
                return Ok("Role updated");
            return NotFound("User not found");
        }

        [HttpDelete("DeleteUser/{id}")]
        public IActionResult DeleteUser(int id)
        {
            if (_userService.DeleteUser(id))
                return Ok("User deleted");
            return NotFound("User not found");
        }
    }
}
