﻿namespace UserManagement.Services.Interface
{
    public interface IAuthService
    {
        string Login(string username, string password);
        bool Register(string username, string password, string role = "Viewer");
    }
}
