﻿using UserManagement.Models;

namespace UserManagement.Services.Interface
{
    public interface IUserService
    {
        IEnumerable<User> GetAllUsers();
        bool UpdateUserRole(int userId, string newRole);
        bool DeleteUser(int userId);
    }
}
