﻿using UserManagement.Models;

namespace UserManagement.Services.Interface
{
    public interface IDocumentService
    {
        IEnumerable<Document> GetAllDocuments();
        Document GetDocumentById(int id);
        void UploadDocument(Document document);
        void UpdateDocument(Document document);
        void DeleteDocument(int id);
    }
}
