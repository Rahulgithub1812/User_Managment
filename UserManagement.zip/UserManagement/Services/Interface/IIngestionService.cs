﻿namespace UserManagement.Services.Interface
{
    public interface IIngestionService
    {
        Task TriggerIngestionAsync();
        Task<string> GetIngestionStatusAsync();
        Task<bool> CancelIngestionAsync();
    }
}
