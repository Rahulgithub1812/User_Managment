﻿using UserManagement.Data;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UserManagement.Services.Service
{
    public class UserService : IUserService
    {
        private readonly ProDBContext _context;

        public UserService(ProDBContext context)
        {
            _context = context;
        }

        public IEnumerable<User> GetAllUsers() => _context.Users.ToList();

        public bool UpdateUserRole(int userId, string newRole)
        {
            var user = _context.Users.Find(userId);
            if (user == null) return false;
            user.Role = newRole;
            _context.SaveChanges();
            return true;
        }

        public bool DeleteUser(int userId)
        {
            var user = _context.Users.Find(userId);
            if (user == null) return false;
            _context.Users.Remove(user);
            _context.SaveChanges();
            return true;
        }
    }

}
