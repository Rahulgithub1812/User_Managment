﻿using UserManagement.Services.Interface;

namespace UserManagement.Services.Service
{
    public class IngestionHttpClient : IIngestionService
    {
        private readonly HttpClient _httpClient;

        public IngestionHttpClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task TriggerIngestionAsync()
        {
            await _httpClient.PostAsync("/api/ingestion/trigger", null);
        }

        public async Task<string> GetIngestionStatusAsync()
        {
            var response = await _httpClient.GetAsync("/api/ingestion/status");
            return await response.Content.ReadAsStringAsync();
        }

        public async Task<bool> CancelIngestionAsync()
        {
            var response = await _httpClient.PostAsync("/api/ingestion/cancel", null);
            return response.IsSuccessStatusCode;
        }
    }

}
