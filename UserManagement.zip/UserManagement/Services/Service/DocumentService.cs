﻿using UserManagement.Data;
using UserManagement.Models;
using UserManagement.Services.Interface;

namespace UserManagement.Services.Service
{
    public class DocumentService : IDocumentService
    {
        private readonly ProDBContext _context;

        public DocumentService(ProDBContext context)
        {
            _context = context;
        }

        public IEnumerable<Document> GetAllDocuments() => _context.Documents.ToList();

        public Document GetDocumentById(int id) => _context.Documents.Find(id);

        public void UploadDocument(Document document)
        {
            _context.Documents.Add(document);
            _context.SaveChanges();
        }

        public void UpdateDocument(Document document)
        {
            _context.Documents.Update(document);
            _context.SaveChanges();
        }

        public void DeleteDocument(int id)
        {
            var doc = _context.Documents.Find(id);
            if (doc != null)
            {
                _context.Documents.Remove(doc);
                _context.SaveChanges();
            }
        }
    }
}
