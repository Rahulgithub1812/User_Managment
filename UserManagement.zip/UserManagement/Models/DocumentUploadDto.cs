﻿namespace UserManagement.Models
{
    public class DocumentUploadDto
    {
        public string Name { get; set; }
        public string Content { get; set; }
    }
}
